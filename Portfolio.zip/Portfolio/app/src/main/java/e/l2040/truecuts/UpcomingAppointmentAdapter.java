package e.l2040.truecuts;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class UpcomingAppointmentAdapter extends RecyclerView.Adapter<UpcomingAppointmentAdapter.UpcomingAppointmentViewHolder>{

    private Context ctx;
    private List<UpcomingAppointment> upcomingAppointmentList;
    private OnHorizontalRecyclerListener mOnHorizontalRecyclerListener;

    public UpcomingAppointmentAdapter(Context ctx, List<UpcomingAppointment> upcomingAppointmentList, OnHorizontalRecyclerListener onHorizontalRecyclerListener) {
        this.ctx = ctx;
        this.upcomingAppointmentList = upcomingAppointmentList;
        this.mOnHorizontalRecyclerListener = onHorizontalRecyclerListener;
    }

    @NonNull
    @Override
    public UpcomingAppointmentViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(ctx);
        View view = inflater.inflate(R.layout.horizontal_layout,viewGroup, false);
        return new UpcomingAppointmentViewHolder(view, mOnHorizontalRecyclerListener);
    }

    @Override
    public void onBindViewHolder(@NonNull UpcomingAppointmentViewHolder upcomingAppointmentViewHolder, int position) {
        UpcomingAppointment upcomingAppointment = upcomingAppointmentList.get(position);

        upcomingAppointmentViewHolder.barberShopName.setText(upcomingAppointment.getBarberShopName());
        upcomingAppointmentViewHolder.appointmentDay.setText(upcomingAppointment.getDay());
        upcomingAppointmentViewHolder.monthAndYear.setText(upcomingAppointment.getMonthAndYear());
        upcomingAppointmentViewHolder.image.setBackground(ctx.getResources().getDrawable(upcomingAppointment.getImage()));

    }

    @Override
    public int getItemCount() {
        return upcomingAppointmentList.size();
    }

    class UpcomingAppointmentViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{


        TextView barberShopName;
        TextView appointmentDay;
        TextView monthAndYear;
        ImageView image;

        OnHorizontalRecyclerListener onHorizontalRecyclerListener;

        public UpcomingAppointmentViewHolder(@NonNull View itemView, OnHorizontalRecyclerListener onHorizontalRecyclerListener) {
            super(itemView);

            barberShopName = itemView.findViewById(R.id.barberShopNameHorizontal);
            appointmentDay = itemView.findViewById(R.id.theDay);
            monthAndYear = itemView.findViewById(R.id.monthAndYear);
            image = itemView.findViewById(R.id.imageHorizontal);
            this.onHorizontalRecyclerListener = onHorizontalRecyclerListener;

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            onHorizontalRecyclerListener.onHorizontalRecyclerClick(getAdapterPosition());
        }
    }


    public interface OnHorizontalRecyclerListener{
        void onHorizontalRecyclerClick(int position);
    }
}
