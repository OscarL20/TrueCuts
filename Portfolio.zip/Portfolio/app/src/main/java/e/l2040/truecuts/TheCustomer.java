package e.l2040.truecuts;

public class TheCustomer {


    private String customerName;
    private String time;
    private int image;


    public TheCustomer(String customerName, String time, int image) {
        this.customerName = customerName;
        this.time = time;
        this.image = image;
    }


    public String getCustomerName() {
        return customerName;
    }

    public String getTime() {
        return time;
    }

    public int getImage() {
        return image;
    }
}
