package e.l2040.truecuts;

public class RecentAppointment {


    private String barberShop;
    private String barber;
    private String address;
    private int image;

    public RecentAppointment(String barberShop, String barber, String address, int image) {
        this.barberShop = barberShop;
        this.barber = barber;
        this.address = address;
        this.image = image;
    }


    public String getBarberShop() {
        return barberShop;
    }

    public String getBarber() {
        return barber;
    }

    public String getAddress() {
        return address;
    }

    public int getImage() {
        return image;
    }
}
