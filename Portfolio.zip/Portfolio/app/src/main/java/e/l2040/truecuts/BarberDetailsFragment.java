package e.l2040.truecuts;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;


public class BarberDetailsFragment extends Fragment implements View.OnClickListener {

    Button back;
    Button messages;
    Button bookAppointment;

    RecyclerView recyclerView;
    PhotoAdapter photoAdapter;
    List<Photo> photoList;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_barber_details, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        back = view.findViewById(R.id.back);
        back.setOnClickListener(this);

        messages = view.findViewById(R.id.messages);
        messages.setOnClickListener(this);

        bookAppointment = view.findViewById(R.id.bookAppointment);
        bookAppointment.setOnClickListener(this);


        photoList = new ArrayList<>();

        recyclerView = (RecyclerView) getView().findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));

        photoList.add(
                new Photo(R.drawable.barbershopoutside));
        photoList.add(
                new Photo(R.drawable.barbershopoutside));
        photoList.add(
                new Photo(R.drawable.barbershopoutside));
        photoList.add(
                new Photo(R.drawable.barbershopoutside));
        photoList.add(
                new Photo(R.drawable.barbershopoutside));



        photoAdapter = new PhotoAdapter(getContext(), photoList);
        recyclerView.setAdapter(photoAdapter);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.back:
                getFragmentManager().beginTransaction().replace(R.id.fragment_container, new SearchFragment()).commit();
                break;

            case R.id.messages:
                getFragmentManager().beginTransaction().replace(R.id.fragment_container, new MessagesFragment()).commit();
                break;

            case R.id.bookAppointment:
                getFragmentManager().beginTransaction().replace(R.id.fragment_container, new BookAppointmentFragment()).commit();
                break;

        }
    }
}
