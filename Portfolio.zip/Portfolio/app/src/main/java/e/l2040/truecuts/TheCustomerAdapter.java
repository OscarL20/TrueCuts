package e.l2040.truecuts;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class TheCustomerAdapter extends RecyclerView.Adapter<TheCustomerAdapter.TheCustomerViewHolder>{

    private Context ctx;
    private List<TheCustomer> theCustomerList;

    public TheCustomerAdapter(Context ctx, List<TheCustomer> theCustomerList) {
        this.ctx = ctx;
        this.theCustomerList = theCustomerList;
    }

    @NonNull
    @Override
    public TheCustomerViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(ctx);
        View view = inflater.inflate(R.layout.activity_customer,viewGroup, false);
        return new TheCustomerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TheCustomerViewHolder theCustomerViewHolder, int position) {
        TheCustomer theCustomer = theCustomerList.get(position);

        theCustomerViewHolder.customerName.setText(theCustomer.getCustomerName());
        theCustomerViewHolder.time.setText(theCustomer.getTime());
        theCustomerViewHolder.image.setImageDrawable(ctx.getResources().getDrawable(theCustomer.getImage()));
    }

    @Override
    public int getItemCount() {
        return theCustomerList.size();
    }

    class TheCustomerViewHolder extends RecyclerView.ViewHolder{

        TextView customerName;
        TextView time;
        ImageView image;

        public TheCustomerViewHolder(@NonNull View itemView) {
            super(itemView);


            customerName = itemView.findViewById(R.id.customerName);
            time = itemView.findViewById(R.id.time);
            image = itemView.findViewById(R.id.image);
        }
    }
}
