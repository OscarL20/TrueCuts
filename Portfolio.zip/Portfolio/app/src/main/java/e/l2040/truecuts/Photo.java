package e.l2040.truecuts;

public class Photo {

    private int image;

    public Photo(int image) {
        this.image = image;
    }


    public int getImage() {
        return image;
    }

}
