package e.l2040.truecuts;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;


public class BookAppointmentFragment extends Fragment implements View.OnClickListener {

    Button back;
    Button favorites;
    Button bookNow;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_book_appointment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        back = view.findViewById(R.id.back);
        back.setOnClickListener(this);

        favorites = view.findViewById(R.id.favorites);
        favorites.setOnClickListener(this);

        bookNow = view.findViewById(R.id.bookNow);
        bookNow.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.back:
                getFragmentManager().beginTransaction().replace(R.id.fragment_container, new BarberDetailsFragment()).commit();
                break;

            case R.id.favorites:
                Toast.makeText(getContext(), "Added to Favorites", Toast.LENGTH_SHORT).show();
                break;

            case R.id.bookNow:
                getFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
                break;

        }

    }
}
