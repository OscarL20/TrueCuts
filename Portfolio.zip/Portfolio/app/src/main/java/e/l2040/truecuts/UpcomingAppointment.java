package e.l2040.truecuts;

public class UpcomingAppointment {


    private String barberShopName;
    private String day;
    private String monthAndYear;
    private int image;

    public UpcomingAppointment(String barberShopName, String day, String monthAndYear, int image) {
        this.barberShopName = barberShopName;
        this.day = day;
        this.monthAndYear = monthAndYear;
        this.image = image;
    }


    public String getBarberShopName() {
        return barberShopName;
    }

    public String getDay() {
        return day;
    }

    public String getMonthAndYear() {
        return monthAndYear;
    }

    public int getImage() {
        return image;
    }
}
