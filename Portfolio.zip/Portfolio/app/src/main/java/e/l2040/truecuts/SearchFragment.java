package e.l2040.truecuts;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


public class SearchFragment extends Fragment implements View.OnClickListener, RecentAppointmentAdapter.OnRecyclerListener {

    Button back;


    RecyclerView recyclerView;
    RecentAppointmentAdapter recentAppointmentAdapter;
    List<RecentAppointment> searchResultsList;


    EditText zipcode;

    @Override
    public void onRecyclerClick(int position) {
        getFragmentManager().beginTransaction().replace(R.id.fragment_container, new BarberDetailsFragment()).commit();
    }


    public class DownloadTask extends AsyncTask<String, Void, String[]> {

        @Override
        protected String[] doInBackground(String... urls) {
            String result = "";
            URL url;
            HttpURLConnection urlConnection = null;
            String[] urlAndData = new String[2];

            try{

                url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = urlConnection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                int incomingJson = reader.read();

                while (incomingJson != -1) {
                    char current = (char) incomingJson;
                    result += current;
                    incomingJson = reader.read();
                }

                urlAndData[0] = urls[0];
                urlAndData[1] = result;

                return urlAndData;

            }catch (Exception e){
                e.printStackTrace();
                return null;
            }

        }


        @Override
        protected void onPostExecute(String[] s) {
            super.onPostExecute(s);
            //longInfo(s);
            String lat = "";
            String lng = "";

            if (s[0].equals("https://maps.googleapis.com/maps/api/geocode/json?address=" + zipcode.getText().toString() + "&key=AIzaSyDfymk8ZpGnSuKTs76t5PAGrhvcsGIDYEU")){

                try {
                    JSONObject jsonObject = new JSONObject(s[1]);
                    String results = jsonObject.getString("results");
                    JSONArray jsonArray = new JSONArray(results);


                    for (int i = 0; i < jsonArray.length(); i++){
                        JSONObject areaInfo = jsonArray.getJSONObject(i);
                        JSONObject jsonObject1 = areaInfo.getJSONObject("geometry");
                        JSONObject jsonObject2 = jsonObject1.getJSONObject("location");
                        lat = jsonObject2.getString("lat");
                        lng = jsonObject2.getString("lng");
                    }

                    passOnLatAndLng(lat, lng);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }else{
                //barberList.clear();************substitute with searchResultList
                searchResultsList.clear();
                try {
                    JSONObject jsonObject = new JSONObject(s[1]);
                    String barbersNearBy = jsonObject.getString("results");
                    JSONArray jsonArray = new JSONArray(barbersNearBy);


                    for (int i = 0; i < jsonArray.length(); i++){
                        JSONObject barber = jsonArray.getJSONObject(i);

                        //barberList.add(barber.getString("name"));**************substitute with searchResultList
                        searchResultsList.add(
                                new RecentAppointment(
                                        barber.getString("name"),
                                        "Oscar Lopez",
                                        barber.getString("vicinity"),
                                        R.drawable.barbershopoutside));
                        //arrayAdapter.notifyDataSetChanged();******************use this with our new adapter
                        recentAppointmentAdapter.notifyDataSetChanged();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }


        }
    }

    public void passOnLatAndLng(String lat, String lng){
        DownloadTask downloadTask1 = new DownloadTask();
        downloadTask1.execute("https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=" + lat + "," + lng + "&radius=5000&type=barber&keyword=barber&key=AIzaSyDfymk8ZpGnSuKTs76t5PAGrhvcsGIDYEU");
    }



    public void showList(View view){
        zipcode.clearFocus();
        InputMethodManager inputMethodManager = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);

        DownloadTask downloadTask = new DownloadTask();
        downloadTask.execute("https://maps.googleapis.com/maps/api/geocode/json?address=" + zipcode.getText().toString() + "&key=AIzaSyDfymk8ZpGnSuKTs76t5PAGrhvcsGIDYEU");
        //Intent intent = new Intent (this, Login.class);
        //startActivity(intent);
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_search, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        back = view.findViewById(R.id.back);
        back.setOnClickListener(this);



        zipcode = (EditText) getView().findViewById(R.id.editText);
        zipcode.requestFocus();
        zipcode.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    showList(v);
                    return true;
                }
                return false;
            }
        });



        searchResultsList = new ArrayList<>();

        recyclerView = (RecyclerView) getView().findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));


        recentAppointmentAdapter = new RecentAppointmentAdapter(getContext(), searchResultsList, this);
        recyclerView.setAdapter(recentAppointmentAdapter);

    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.back:
                getFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
                break;

        }

    }
}
