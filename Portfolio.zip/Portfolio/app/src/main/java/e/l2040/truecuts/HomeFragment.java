package e.l2040.truecuts;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;


public class HomeFragment extends Fragment implements View.OnClickListener, RecentAppointmentAdapter.OnRecyclerListener, UpcomingAppointmentAdapter.OnHorizontalRecyclerListener {

    DrawerLayout drawerLayout;
    Button search;
    Button toggle;

    RecyclerView recyclerView;
    RecentAppointmentAdapter recentAppointmentAdapter;
    List<RecentAppointment> recentAppointmentList;

    RecyclerView recyclerView1;
    UpcomingAppointmentAdapter upcomingAppointmentAdapter;
    List<UpcomingAppointment> upcomingAppointmentList;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }



    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        search = view.findViewById(R.id.search);
        search.setOnClickListener(this);

        toggle = view.findViewById(R.id.toggle);
        toggle.setOnClickListener(this);
        drawerLayout = (DrawerLayout) getActivity().findViewById(R.id.drawerLayout);


        recentAppointmentList = new ArrayList<>();

        recyclerView = (RecyclerView) getView().findViewById(R.id.recentRecyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));


        upcomingAppointmentList = new ArrayList<>();

        recyclerView1 = (RecyclerView) getView().findViewById(R.id.upcomingRecyclerView);
        recyclerView1.setHasFixedSize(true);
        recyclerView1.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));


        recentAppointmentList.add(
                new RecentAppointment(
                        "The Barber",
                        "Oscar Lopez",
                        "13529 Theboss Ave.",
                        R.drawable.barbershopoutside));

        recentAppointmentList.add(
                new RecentAppointment(
                        "The Barber",
                        "Oscar Lopez",
                        "13529 Theboss Ave.",
                        R.drawable.barbershopoutside));

        recentAppointmentList.add(
                new RecentAppointment(
                        "The Barber",
                        "Oscar Lopez",
                        "13529 Theboss Ave.",
                        R.drawable.barbershopoutside));

        recentAppointmentList.add(
                new RecentAppointment(
                        "The Barber",
                        "Oscar Lopez",
                        "13529 Theboss Ave.",
                        R.drawable.barbershopoutside));


        upcomingAppointmentList.add(
                new UpcomingAppointment(
                        "The Best Barber",
                        "18",
                        "June, 2019",
                        R.drawable.barbershopoutside));

        upcomingAppointmentList.add(
                new UpcomingAppointment(
                        "The Best Barber",
                        "18",
                        "June, 2019",
                        R.drawable.barbershopoutside));
        upcomingAppointmentList.add(
                new UpcomingAppointment(
                        "The Best Barber",
                        "18",
                        "June, 2019",
                        R.drawable.barbershopoutside));


        recentAppointmentAdapter = new RecentAppointmentAdapter(getContext(), recentAppointmentList, this);
        recyclerView.setAdapter(recentAppointmentAdapter);

        upcomingAppointmentAdapter = new UpcomingAppointmentAdapter(getContext(), upcomingAppointmentList, this);
        recyclerView1.setAdapter(upcomingAppointmentAdapter);

    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.toggle:
                drawerLayout.openDrawer(Gravity.LEFT);
                break;

            case R.id.search:
                getFragmentManager().beginTransaction().replace(R.id.fragment_container, new SearchFragment()).commit();
                break;

        }

    }

    @Override
    public void onRecyclerClick(int position) {

        getFragmentManager().beginTransaction().replace(R.id.fragment_container, new BarberDetailsFragment()).commit();
    }


    @Override
    public void onHorizontalRecyclerClick(int position) {

        getFragmentManager().beginTransaction().replace(R.id.fragment_container, new AppointmentDetailsFragment()).commit();
    }
}
